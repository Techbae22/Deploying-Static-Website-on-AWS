Please below my CloudFront and S3 bucket links

Distribution domain name (cloudfront): https://d1273b2mkzznth.cloudfront.net
S3: http://my-aws-bucket13.s3-website-us-east-1.amazonaws.com
